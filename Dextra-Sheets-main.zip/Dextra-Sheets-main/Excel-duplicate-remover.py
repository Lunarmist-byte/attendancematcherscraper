import pandas as pd

input_file_path = 'EC-Final-Data-with-Duplicates.xlsx'
output_file_path = 'EC-Cleaned-Final-Data.xlsx'


try:
    df = pd.read_excel(input_file_path)
except FileNotFoundError as e:
    print(f"Error: File not found. Please check the file name: {e}")
    exit()

rows_before = len(df)


df_cleaned = df.drop_duplicates(
    subset=['Name', 'Department', 'Event'], 
    keep='first'
)

rows_after = len(df_cleaned)


df_cleaned.to_excel(output_file_path, index=False)

print("-" * 50)
print(f"✅ Data cleaned successfully.")
print(f"   Original records: {rows_before}")
print(f"   Duplicate rows removed: {rows_before - rows_after}")
print(f"   Final unique records: {rows_after}")
print(f"File saved to: {output_file_path}")
print("-" * 50)

#Script By Goutham Sankar
