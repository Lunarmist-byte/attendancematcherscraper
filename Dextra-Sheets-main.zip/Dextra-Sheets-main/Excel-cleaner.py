import pandas as pd


file1_path = 'EC-File-uncleaned-1.xlsx'
file2_path = 'EC-File-uncleaned-2.xlsx'
output_file_path = 'EC-Final-Data-with-Duplicates.xlsx'


try:
    df1 = pd.read_excel(file1_path, sheet_name=0) 
    df2 = pd.read_excel(file2_path, sheet_name=0)
except FileNotFoundError as e:
    print(f"Error: One of the files was not found. Please check the file name: {e}")
    exit()



df1.columns = df1.columns.str.strip()
df2.columns = df2.columns.str.strip()

df2 = df2.rename(columns={'Phone Number': 'Phone'})

for df in [df1, df2]:
    for col in ['Name', 'Department', 'Semester']:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip()




merged_df = pd.merge(
    left=df1, 
    right=df2[['Name', 'Department', 'Semester', 'Email', 'Phone']], 
    on=['Name', 'Department', 'Semester'],
    how='left' 
)



final_df = merged_df[[
    'Name', 
    'Department', 
    'Semester', 
    'Event',
    'Phone',
    'Email'
]].copy()

final_df = final_df.rename(columns={'Phone': 'Phone Number'})



final_df.to_excel(output_file_path, index=False)

print("-" * 60)
print(f"✅ Success! Data merged using (Name, Department, Semester) as keys.")
print(f"File saved to: {output_file_path}")
print(f"Total records in new file: {len(final_df)}")
print("-" * 60)
